package com.example.satramprudhvi.electricitybiilling;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Calendar;
import java.util.Date;

public class ElectricityBillActivity extends AppCompatActivity {
//private String CustomerId;
//private String customerName;
//private String customerEmail;
//private Date billDate;
//private double unitsConsumed;
//private double totalBillAmount;



//    public ElectricityBillActivity(String customerId, String customerName, String customerEmail, Date billDate, double unitsConsumed, double totalBillAmount) {
//        CustomerId = customerId;
//        this.customerName = customerName;
//        this.customerEmail = customerEmail;
//        this.billDate = billDate;
//        this.unitsConsumed = unitsConsumed;
//        this.totalBillAmount = totalBillAmount;
//    }
//
//    public String getCustomerId() {
//        return CustomerId;
//    }
//
//    public void setCustomerId(String customerId) {
//        CustomerId = customerId;
//    }
//
//    public String getCustomerName() {
//        return customerName;
//    }
//
//    public void setCustomerName(String customerName) {
//        this.customerName = customerName;
//    }
//
//    public String getCustomerEmail() {
//        return customerEmail;
//    }
//
//    public void setCustomerEmail(String customerEmail) {
//        this.customerEmail = customerEmail;
//    }
//
//    public Date getBillDate() {
//        return billDate;
//    }
//
//    public void setBillDate(Date billDate) {
//        this.billDate = billDate;
//    }
//
//    public double getUnitsConsumed() {
//        return unitsConsumed;
//    }
//
//    public void setUnitsConsumed(double unitsConsumed) {
//        this.unitsConsumed = unitsConsumed;
//    }
//
//    public double getTotalBillAmount() {
//        return totalBillAmount;
//    }
//
//    public void setTotalBillAmount(double totalBillAmount) {
//        this.totalBillAmount = totalBillAmount;
//    }
private static final String TAG = "EletrcityBillActivity";
    private TextView displaydate;
    private DatePickerDialog.OnDateSetListener mDateSetListner;



    private Button calculatebutton;
    EditText customerid;
    EditText customername;
    EditText customeremail;
    EditText customerunitsconsumed;
    String customerEmail;
    String customerName;
    String customerunitsConsumed;
    String gtcustomerid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electricity_bill);
        //String content = edtEditText.getText().toString(); //gets you the contents of edit text
        //tvTextView.setText(content);
        //
        calculatebutton = (Button)findViewById(R.id.calculatebutton);
       customerid  = findViewById(R.id.customerid);
       customername = findViewById(R.id.customername);
       customeremail = findViewById(R.id.customeremail);
       customerunitsconsumed = findViewById(R.id.unitscosumed);

       // final ElectricityCalculation ec = new ElectricityCalculation();

        calculatebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ElectricityBillActivity.this, BillDetailsActivity.class);

                gtcustomerid = customerid.getText().toString();
                customerEmail = customeremail.getText().toString();
                customerName = customername.getText().toString();
                customerunitsConsumed = customerunitsconsumed.getText().toString();
                Log.d("CUSTOMERID", gtcustomerid);
                intent.putExtra("gtcustomerid",gtcustomerid);
                intent.putExtra("customername",customerName);
                intent.putExtra("customeremail",customerEmail);
                intent.putExtra("unitsconsumed",customerunitsConsumed);
                //ec.calculation();
                startActivity(intent);
                finish();

            }
        });

        displaydate = (TextView)findViewById(R.id.displaydate);
        displaydate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(ElectricityBillActivity.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth ,mDateSetListner,year,month,day);
           dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
           dialog.show();
            }
        });
        mDateSetListner = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                String date = month +"/" + day +"/" + year ;
                displaydate.setText(date);

            }
        };

//        buttonLogout = (Button) findViewById(R.id.btn_logout);
//        buttonLogout.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                mPreferences = getSharedPreferences("CurrentUser", MODE_PRIVATE);
//                SharedPreferences.Editor editor=mPreferences.edit();
//                editor.remove("UserName");
//                editor.remove("PassWord");
//                editor.commit();
//                Message myMessage=new Message();
//                myMessage.obj="NOTSUCCESS";
//                handler.sendMessage(myMessage);
//                finish();
//            }
//        });
//
//
//
//
//        private Handler handler = new Handler() {
//            @Override
//            public void handleMessage(Message msg) {
//                String loginmsg=(String)msg.obj;
//                if(loginmsg.equals("NOTSUCCESS")) {
//                    Intent intent = new Intent(getApplicationContext(), LoginError.class);
//                    intent.putExtra("LoginMessage", "Logged Out");
//                    startActivity(intent);
//                    removeDialog(0);
//                }
//            }
//        };

    }

}//
//
//mydb mydb =new mydb(this);//object
//    SQLiteDatabase db = mydb.getWritableDatabase();
//    //writing values
//    ContentValues values = new ContentValues();
//        values.put("name" , username);
//                values.put("email" , useremail);
//                values.put("password" , userpassword);
//                values.put("phone", userphone);
//                db.insert("customers", null,values);
//                Toast.makeText(this , "INSERTED!", Toast.LENGTH_LONG).show();
