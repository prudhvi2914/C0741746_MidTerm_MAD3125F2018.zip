package com.example.satramprudhvi.electricitybiilling;

public class ElectricityCalculation extends  BillDetailsActivity {

    double a = 0.0;

        public static void main(String[] args) {

//Scanner reader = new Scanner(System.in);
//System.out.println("Enter the number units: ");
//double a = reader.nextInt();
//            ElectricityCalculation ec = new ElectricityCalculation();


                 //ec.calculation();



        }
        public static double calculation(int units) {

            double result=0;
            if (units < 100) {
                result = units * 0.75;
//                System.out.println("The total cost is $" + result);
            }
            if (units >= 100 && units <= 150) {
                double b = units - 100;
                result = (100 * 0.75) + (b * 1.25);
//                System.out.println("The total cost is $" + result);
            }
            if (units > 150 && units <= 200) {
                double c = units - 150;
                result = (150 * 1.25) + (c * 1.75);
//                System.out.println("The total cost is $" + result);
            }
            if (units > 200 && units <= 450) {

                result = units * 1.75;
//                System.out.println("The total cost is $" + result);
            }
            if (units > 450) {
                result = units * 2.25;
//                System.out.println("The total cost is $" + result);
            }
            return result;
        }
    }


