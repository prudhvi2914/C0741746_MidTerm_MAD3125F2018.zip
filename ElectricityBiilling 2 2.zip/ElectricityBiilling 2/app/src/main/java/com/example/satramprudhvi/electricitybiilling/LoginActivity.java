package com.example.satramprudhvi.electricitybiilling;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
SQLiteDatabase db;
  SQLiteOpenHelper openHelper;
   EditText loginemail,loginpassword;
   TextView logintextview;
   Button loginbutton;
  Cursor cursor ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        loginemail = (EditText)findViewById(R.id.loginemail);
        loginpassword = (EditText)findViewById(R.id.loginpassword);
        loginbutton = (Button) findViewById(R.id.loginbutton);
        logintextview = (TextView)findViewById(R.id.logintextview);



        openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(LoginActivity.this,ElectricityBillActivity.class);

                String email = loginemail.getText().toString();
                String password = loginpassword.getText().toString();
                cursor = db.rawQuery(" SELECT *FROM  " +  DatabaseHelper.TABLE_NAME  + " WHERE " +  DatabaseHelper.COL_5  + " =?  AND " + DatabaseHelper.COL_4 + " =? " , new String[]{ email ,password});
//                startActivity(new Intent(LoginActivity.this,ElectricityBillActivity.class ));
                if (cursor != null){

                    if (cursor.getCount() > 0 ){

                        cursor.moveToNext();

                        Toast.makeText(getApplicationContext(), "LOGIN SUCESSFULL",Toast.LENGTH_SHORT).show();
//                        Intent intent = new Intent(LoginActivity.this, ElectricityBillActivity.class); startActivity(intent);
                        startActivity(intent);

                    }else {
                        Toast.makeText(getApplicationContext(),"ERROR INVALID USERNAME OR PASSWORD",Toast.LENGTH_SHORT).show();
                    }
                }
//               startActivity(intent);

            }


        });

        logintextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

//
    }
}